 package com.example.bookmanagement.controller;

import com.example.bookmanagement.model.Book;
import com.example.bookmanagement.repository.BookRepository;
import com.example.bookmanagement.repository.BookNotFoundException;

import java.io.IOException;
import java.util.List;

public class BookController {
    private BookRepository repository;
    
    public BookController(BookRepository repository) {
        this.repository = repository;
    }

    public void addBook(String title, String author, String isbn, int year) {
        // 객체생성 후 넘긴다 controller에서???
    	Book book = new Book(title, author, isbn, year);
    	repository.addBook(book);
    }

    public void removeBook(String isbn) throws BookNotFoundException {
    	// 코드 구현
    	repository.removeBook(isbn);
    }

    public Book getBook(String isbn) throws BookNotFoundException {
    	// 코드 구현
        return repository.getBook(isbn);
    }

    public List<Book> getAllBooks() {
    	// 코드 구현
    	return repository.getAllBooks();
    }

    public void saveBooks(String filename) throws IOException {
    	// 코드 구현
    	repository.saveBooks(filename);
    }

    public void loadBooks(String filename) throws IOException, ClassNotFoundException {
    	// 코드 구현
    	repository.loadBooks(filename);
    }
}
