package com.example.bookmanagement.repository;

import com.example.bookmanagement.model.Book;

import java.util.List;
import java.io.IOException;

public interface BookRepository {
    void addBook(Book book);
    void removeBook(String isbn) throws BookNotFoundException;
    //Book을 반환
    Book getBook(String isbn) throws BookNotFoundException;
    //List로 반환
    List<Book> getAllBooks();
    void saveBooks(String filename) throws IOException;
    void loadBooks(String filename) throws IOException, ClassNotFoundException;
}
