package com.example.bookmanagement.repository;

import com.example.bookmanagement.model.Book;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FileBookRepository implements BookRepository {
    private List<Book> books = new ArrayList<>();

    @Override
    public void addBook(Book book) {
    	// saveBooks(); 은 필요없음 파일을 저장하는 메소드를 따로 구현했으므로 사용자가 원할때만 데이터를 파일에 쓰도록하는게 주목적 
    	books.add(book);
    	
    }

    @Override
    public void removeBook(String isbn) throws BookNotFoundException {
    	// 코드 구현
    	int a =0;
    	for (Book book:books) {
    		if(book.getIsbn().equals(isbn)) {
    			 a =books.indexOf(book);
    		}
    	}
    	books.remove(a);
    }

    @Override
    public Book getBook(String isbn) throws BookNotFoundException {
    	
    	for (Book book:books) {
    		if(book.getIsbn().equals(isbn)) {
    			return book;
    		}
    	}
    	return null;


    }

    @Override
    public List<Book> getAllBooks() {
    	// 코드 구현
    	return books;
    }

    @Override
    public void saveBooks(String filename) throws IOException {
    	// 코드 구현
    	ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(filename)));
    	oos.writeObject(books);
    	
    }

    @Override
    public void loadBooks(String filename) throws IOException, ClassNotFoundException {
    	// 코드 구현
    	ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(filename)));
    	books = (List)ois.readObject();
    	
    }
}
