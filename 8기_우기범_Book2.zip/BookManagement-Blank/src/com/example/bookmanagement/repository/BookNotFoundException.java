package com.example.bookmanagement.repository;

public class BookNotFoundException extends Exception {
	public BookNotFoundException() {}
    public BookNotFoundException(String message) {
        super(message);
        
    }
}
