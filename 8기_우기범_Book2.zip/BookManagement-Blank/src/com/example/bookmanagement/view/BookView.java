package com.example.bookmanagement.view;

import com.example.bookmanagement.controller.BookController;
import com.example.bookmanagement.model.Book;
import com.example.bookmanagement.repository.BookNotFoundException;
import com.example.bookmanagement.repository.BookRepository;
import com.example.bookmanagement.repository.FileBookRepository;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class BookView {
    private BookController controller;
    private Scanner scanner;

    public BookView(BookController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    public void displayBook(Book book) {
        System.out.println("제목: " + book.getTitle());
        System.out.println("저자: " + book.getAuthor());
        System.out.println("ISBN: " + book.getIsbn());
        System.out.println("출판 연도: " + book.getYear());
    }

    public void displayAllBooks(List<Book> books) {
        for (Book book : books) {
            displayBook(book);
            System.out.println("----------");
        }
    }

    public void displayError(String message) {
        System.out.println("오류: " + message);
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void showMenu() {
        while (true) {
            System.out.println("1. 도서 추가");
            System.out.println("2. 도서 삭제");
            System.out.println("3. 도서 조회");
            System.out.println("4. 모든 도서 조회");
            System.out.println("5. 도서 저장");
            System.out.println("6. 도서 불러오기");
            System.out.println("7. 종료");
            System.out.print("원하는 작업을 선택하세요: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // 개행 문자 소비

            try {
                switch (choice) {
                    case 1:
                        addBook();
                        break;
                    case 2:
                        removeBook();
                        break;
                    case 3:
                        viewBook();
                        break;
                    case 4:
                        viewAllBooks();
                        break;
                    case 5:
                        saveBooks();
                        break;
                    case 6:
                        loadBooks();
                        break;
                    case 7:
                        System.out.println("종료합니다.");
                        return;
                    default:
                        System.out.println("잘못 입력했습니다. 다시 시도하세요.");
                }
            } catch (BookNotFoundException e) {
                displayError(e.getMessage());
            } catch (IOException | ClassNotFoundException e) {
                displayError("파일 처리 중 오류가 발생했습니다: " + e.getMessage());
            } catch (InputMismatchException e) {
            	displayError(e.getMessage());
            }
        }
    }

    private void addBook() {
        System.out.print("제목을 입력하세요: ");
        String title = scanner.nextLine();
        System.out.print("저자를 입력하세요: ");
        String author = scanner.nextLine();
        System.out.print("ISBN을 입력하세요: ");
        String isbn = scanner.nextLine();
        System.out.print("출판 연도를 입력하세요: ");
        int year = scanner.nextInt();
        scanner.nextLine();  // 개행 문자 소비

        controller.addBook(title, author, isbn, year);
        displayMessage("도서가 성공적으로 추가되었습니다.");
    }

    private void removeBook() throws BookNotFoundException {
        System.out.print("ISBN을 입력하세요: ");
        String isbn = scanner.nextLine();
        controller.removeBook(isbn);
        if (controller.getBook(isbn) == null) {
        	displayMessage("도서가 성공적으로 삭제되었습니다.");
        }else {
        	throw new BookNotFoundException();
        }
        
    }

    private void viewBook() throws BookNotFoundException {
        System.out.print("ISBN을 입력하세요: ");
        String isbn = scanner.nextLine();
        Book book;
		book = controller.getBook(isbn);
		
		if (book == null) {
			throw new BookNotFoundException();
		}else {displayBook(book);}
        
    }

    private void viewAllBooks() {
        List<Book> books = controller.getAllBooks();
        displayAllBooks(books);
    }

    private void saveBooks() throws IOException {
        System.out.print("파일 이름을 입력하세요: ");
        String filename = scanner.nextLine();
        controller.saveBooks(filename);
        //if
        displayMessage("도서가 성공적으로 저장되었습니다.");
    }

    private void loadBooks() throws IOException, ClassNotFoundException {
        System.out.print("파일 이름을 입력하세요: ");
        String filename = scanner.nextLine();
        controller.loadBooks(filename);
        //if
        displayMessage("도서가 성공적으로 불러와졌습니다.");
    }

    public static void main(String[] args) {
        BookRepository repository = new FileBookRepository();
        BookController controller = new BookController(repository);
        BookView view = new BookView(controller);
        view.showMenu();
    }
}
