package jpa.basic;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.*;

@Entity
public class Member {
	@Id
	@GeneratedValue
	@Column(name = "MEMBER_ID")
	private Long id;
	
	@Column(name = "USER_NAME")
	private String username;
	
//	private Long teamId;
	
	@ManyToOne //Member(N) : Team(1) 단방향
	@JoinColumn(name = "TEAM_ID") //1대다관계에서 누구이며 조인할때 컬럼이 뭔지 외래키가 뭔지
	private Team team;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String string) {
		this.username = string;
	}
	public Team getTeam() {
		return team;
	}
	public void setTeam(Team team) {
		this.team = team;
//		team.getMembers().add(this);
	}
	
	@Override
	public String toString() {
		return "Member [id=" + id + ", username=" + username + ", team=" + team + "]";
	}
	
	
	
}
