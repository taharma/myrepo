package jpa.basic;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	public static void main(String[] args) {
		// DB연결 성공 , 예외 Exception이 없다면
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		// 트랜젝션 시작
		tx.begin();
		try {
			// DB로 보내서 저장하고 싶다.
			Member member = new Member();
//            member.setId(1L);
//            member.setName("홍길동");

//			member.setId(2L);
//			member.setName("손오공");
			
//			member.setId(3L);
//			member.setName("손오찬");
//			
//			member.setId(4L);
//			member.setName("손오반");
			
			//조회
			// mapping해서 받아올 class , index
			Member findmember = em.find(Member.class, 2L);
			System.out.println("findMember.id = "+ findmember.getId());
			System.out.println("findMember.id = "+ findmember.getName());

			em.persist(member); // commit 관련 문제
			// commit
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
