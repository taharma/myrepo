package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	private static final Object Team = null;
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			Member member = new Member();
			member.setName("홍길동");
			member.setAddress(new Address("a","b","c"));
			member.getFavoriteFoods().add("라면");
			member.getFavoriteFoods().add("치킨");
			member.getFavoriteFoods().add("피자");
			em.persist(member);
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
