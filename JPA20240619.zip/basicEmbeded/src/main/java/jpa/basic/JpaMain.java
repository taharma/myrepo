package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	private static final Object Team = null;
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			Address address = new Address();
			address.setCity("busan");
			
			
			Member member1 =new Member();
			member1.setName("홍길동");
			member1.setAddress(address);
			em.persist(member1);
			
			Address address2 = new Address();
			address2.setCity("seoul");//둘다 바뀜 왜 commit할때 한꺼번에 들어간다.
			//불가능함
			
			Member member2 =new Member();
			member2.setName("손오공");
			member2.setAddress(address2);
			em.persist(member2);
			
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
