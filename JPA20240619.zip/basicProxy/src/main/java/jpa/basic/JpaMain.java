package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	private static final Object Team = null;

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			Team team = new Team();
			team.setName("팀A");
			em.persist(team);
			
			
			Member member = new Member();
			member.setName("홍길동");
			member.setTeam(team);
			em.persist(member);
			
			em.flush();//영속성컨텍스트에 있는 쿼리날라감
			em.clear();//영속성컨텍스트 비우기 
			
			List<Member> resultList = 
					em.createQuery("select m from Member m", Member.class)
					.getResultList();
			for (Member m : resultList) {
				System.out.println(m);
			}
			
			
			
			//1차캐시를 비우고 DB로 가게끔
			//find하면 쿼리가 보내짐 
			//그후 reference하면 쿼리가 나가지 않음
			//Referen는 꼭필요할때만 작동 그러므로 findMember는 비어있다 (가짜)
//			Member findMember = em.find(Member.class, member.getId());
//			
//			System.out.println(findMember.getTeam().getClass());
//			
//			System.out.println(findMember.getTeam().getName());
//			System.out.println(findMember.getClass());//class jpa.basic.Member$HibernateProxy$dVeY53ed
//			System.out.println(findMember.getId());
//			System.out.println(findMember.getName());
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
