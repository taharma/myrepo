package jpa.basic;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Team {
	@Id
	@GeneratedValue
	@Column(name = "TEAM_ID")
	private Long id;
	private String name;
	//team을 생성할때 리스트도 함께  생성
	//멤버들의 대한 정보를 가지고 싶다 다대일 
	//없어도 됨 JPQL로 해결가능 어차피 DB에서 데리고 와야해서 의미없긴함
	//단방향으로 끝내야함 양방향은 꼭 필요할때 
	//mappedBy : One의 변수명 , 주인
	@OneToMany(mappedBy = "team") //Team team 
	private List<Member> members = new ArrayList<>();
//	private Member member;
	
	
	
	
	public Long getId() {
		return id;
	}
//	public List<Member> getMembers() {
//		return members;
//	}
//	public void setMembers(List<Member> members) {
//		this.members = members;
//	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + ", members=" + members + "]";
	}
	
//	둘중하나로 
//	public void addMember(Member member) {
//		member.setTeam(this);
//		members.add(member);
//	}
	
	
}
