package jpa.basic;

public enum RoleType {
	USER, ADMIN //, GUEST
}
