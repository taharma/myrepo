package com.example.mvc.model;

public class MemberData {
	private String id;
	private String name;
	private String age;
}
