package com.example.mvc.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class RequestParamController {
	
	@ResponseBody
	@RequestMapping("requset-param-v1")
	public String requestParamV1(HttpServletRequest request) {
		log.info("requestParamV1() 실행");
		String id = request.getParameter("id");
		log.info("id : {}", id);
		String name = request.getParameter("name");
		log.info("name : {}", name);
		return "index"; //.html 찾는다
	}
	
	/* @RequestParam으로 요청 파라미터를 읽을 수있다. 
	 * 요청 파라미터를 꼭받지 않아도 될 경우 required 속성을 false
	 * 요청 파라미터의 값이 없을 경우 defaultVaule을 설정할수있다.
	 * */
	
	@ResponseBody
	@RequestMapping("requset-param-v2")
	public String requestParamV2(@RequestParam("id") String id
								,@RequestParam(value="name", required = false) String name
								,@RequestParam(value="age", defaultValue = "1") String age) {
		log.info("requestParamV2() 실행");
		log.info("id : {}", id);
		log.info("name : {}", name);
		log.info("age : {}", age);
		return "ok"; //.html 찾는다
	}

	/*  
	 * 파라미터 타입을 지정하지 않고 , Map으로 한번에 받을 수있다.
	 * */
	@ResponseBody
	@RequestMapping("requset-param-map")
	public String requestParamMap(@RequestParam Map<String, String> paramMap) {
		log.info("requestParamMap() 실행");
		log.info("paramMap: {}", paramMap);
		String age = paramMap.get("age");
		log.info("age: {}", age);
		return "ok"; //.html 찾는다
	}
}
