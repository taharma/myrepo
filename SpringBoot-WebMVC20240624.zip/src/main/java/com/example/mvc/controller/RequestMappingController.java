package com.example.mvc.controller;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
public class RequestMappingController {
	
	private final Logger log = LoggerFactory.getLogger(RequestMappingController.class);
	
	
	
	
	/*
	 * @RequestMapping은 HTTP 요청방식을 가리지 않는다
	 * 모든 방식을 처리한다.
	 * 요청값은 배열로 받을수있다
	 */
	@RequestMapping("hello") //value path 둘다 가능
	public String hello() {
		return "Hello World";
	}
	
	@RequestMapping(value="hello-get", method = RequestMethod.GET) //value path 둘다 가능
	public String helloGet() {
		log.info("helloGet() 실행");
		return "Hello Get";
	}
	
	@GetMapping("hello-get-v2") //value path 둘다 가능
	public String helloGetV2() {
		log.info("helloGetV2() 실행");
		return "Hello GetV2";
	}
	
	@PostMapping("hello-post-v2") //value path 둘다 가능
	public String helloPostV2() {
		log.info("helloPostV2() 실행");
		return "Hello PostV2";
	}
	
	@RequestMapping(value="hello-post", method = RequestMethod.POST) //value path 둘다 가능
	public String helloPost() {
		log.info("helloPost() 실행");
		return "Hello Post";
	}
	
	//여러가지이름으로 같은 응답을 받고 싶을때 
	@RequestMapping(path={"hello-1", "hello-2"}) 
	public String helloArray() {
		return "Hello World Array";
	}
	
	//get post 두개를 배열로
	@RequestMapping(path="hello-get-post",method= {RequestMethod.GET, RequestMethod.POST}) 
	public String helloGetPost() {
		log.info("helloGetPost() 실행");
		return "Hello World GetPost";
	}
	
	/*
	 * 경로변수 (PathVariable) 파라미터 변수를 받아올수도 있음,Api통신에 자주이용
	 * ex) localhost:9000/users/user1
	 * 예전) localhost:9000/user?user_id=user1 Get방식
	 * */
	@GetMapping("hello/{userId}")
	public String helloPath(@PathVariable("userId") String userId) {
		log.info("userId: {}", userId);
		return "ok";
	}
	public String getMethodName(@RequestParam String param) {
		return new String();
	}
	
}
