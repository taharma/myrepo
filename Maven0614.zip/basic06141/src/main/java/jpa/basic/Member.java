package jpa.basic;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name="tableName")
public class Member {
	@Id
	private Long id; //wrapper class
//	@Column(name="username" , length = 10, nullable=false , unique = true) 
	//이름은 10자초과 x varchar(10) , constraint 이름도 지어줘야함
	private String name;
//	private int age;
//	private int aaa;
	
	//constrct
	public Member() {
		
	}
	
	
	public Member(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
