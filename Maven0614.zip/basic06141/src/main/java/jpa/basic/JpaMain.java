package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	public static void main(String[] args) {
		// DB연결 성공 , 예외 Exception이 없다면
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		// 트랜젝션 시작
		tx.begin();
		try {
//			em.find(Member.class, 100L);
			//
//			Member member1 = new Member(300L,"홍길동");
//			Member member2 = new Member(301L,"홍길동");
//			Member member3 = new Member(302L,"홍길동");
//			em.persist(member1);
//			em.persist(member2);
//			em.persist(member3);
			
			//JPQL em.flush();가 호출된 이후에 
//			List<Member> resultList = em.createQuery("select m from Member as m", Member.class)
//										.getResultList();
//			for (Member m : resultList) {
//				System.out.println(m.getId());
//			}
//			
			
//			Member member = em.find(Member.class, 100L);
//			member.setName("프리저");
////			em.flush(); 커밋전에 직접호출하여 쏟아냄
//			System.out.println("========");
			// =====이후에 쿼리가 날아감 flush
//			Member member = new Member(200L, "홍길동");
//			em.persist(member);
//			Member member2 = new Member(201L, "손오공");
//			em.persist(member2);
//			System.out.println("==========");

			//비영속
//			Member member = new Member();
//			member.setId(102L);
//			member.setName("홍길동");
			
			//영속
//			em.persist(member);
			
			//준영속상태
//			em.detach(member);
			
			//조회
//			Member findMember1 = em.find(Member.class, 100L);
//			System.out.println(findMember1.getId() + findMember1.getName());
//			//DB를 조회하여 찾아온후 1캐시에 저장했으므로 DB를 조회하지않고 1차캐시만 조회
//			Member findMember2 = em.find(Member.class, 100L);
//			System.out.println(findMember2.getId() + findMember2.getName());
//			
//			System.out.println(findMember1 == findMember2);
			
			// commit
			tx.commit();
			
			
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
