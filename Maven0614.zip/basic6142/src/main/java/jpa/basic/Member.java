package jpa.basic;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Member {
	@Id
	private Long id;
	
	@Column(name="USER_NAME")
	private String username;
	
	@Column(name="USER_AGE")
	private Integer age;
	
	//관리자 , 일반
	@Enumerated(EnumType.STRING)
	private RoleType roleType;
	
	
	
	public void setRoleType(RoleType roleType) {
		this.roleType = roleType;
	}


	//constrct
	public Member() {}
	
	
	
	
	
	
	
}
