package jpa.basic.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import jpa.basic.entity.*;

public class JpaMain {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			Album album = new Album();
			album.setName("rapsody");
			album.setArtist("Queen");
			em.persist(album);
			
			Book book = new Book();
			book.setName("oidipuss");
			book.setAuthor("sopoclass");
			book.setIsbn("1111");
			em.persist(book);
			
			Movie movie = new Movie();
			movie.setName("madmax");
			movie.setDirector("?");
			movie.setActor("benfodd");
			em.persist(movie);
			
			
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();
	}
}
