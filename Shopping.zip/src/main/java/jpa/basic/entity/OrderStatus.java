package jpa.basic.entity;

public enum OrderStatus {
	ORDER, CANCEL
}
