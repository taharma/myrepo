package jpa.basic.entity;

import javax.persistence.*;

@Entity
public class OrderItem {
	@Id
	@GeneratedValue
	@Column(name ="ORDERITEM_ID")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "ORDER_ID")
	private Order order; //주문 자체를 가지고 있음
	
	@ManyToOne
	@JoinColumn(name = "ITEM_ID")
	private Item item;//fk를 가진놈이 주인
	
	private int orderPrice; //주문금액
	
	private int count; //주문수량

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	
}
