package jpa.basic.entity;

import java.time.LocalDateTime;
import java.util.*;

import javax.persistence.*;

@Entity
@Table(name = "ORDERS") //order가 예약어라 오류발생가능성이있다
public class Order {
	@Id
	@GeneratedValue
	@Column(name ="ORDER_ID")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")//snake camell
	private Member member;
	
//	@Column(name = "ORDER_DATE")
	private LocalDateTime orderDate;//주문시간
	
	@Enumerated(EnumType.STRING) //ordinal 이되면 1,2로 표시됨  
	private OrderStatus status;
	
	//내가 주문했던 것들에 어떤것들이 있는가
	//양방향해놓으면 편하지만 굳이 필요없다 JPQL로 구현 가능
	@OneToMany(mappedBy = "order")
	private List<OrderItem> orderItems =  new ArrayList<>();
		
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	
	
	
	
}
