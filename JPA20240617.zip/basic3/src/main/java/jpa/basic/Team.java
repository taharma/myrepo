package jpa.basic;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Team {
	@Id
	@GeneratedValue
	@Column(name = "TEAM_ID")
	private Long id;
	private String name;
	//team을 생성할때 리스트도 함께  생성
	@OneToMany(mappedBy = "team") //Team team 
	private List<Member> member = new ArrayList<>();
//	private Member member;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
