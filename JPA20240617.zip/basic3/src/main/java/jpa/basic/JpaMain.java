package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	private static final Object Team = null;

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			Team team = new Team();
			team.setName("TeamA");
			em.persist(team);
			
			Member member = new Member();
			member.setUsername("홍길동");
			member.setTeam(team);
			em.persist(member);
			
			//객체지향은 멤버가 team객체 자체를 가지고 있으니
			//id 같은건 필요없다
//			Member findMember = em.find(Member.class, member);
//			System.out.println(findMember);
			
//			//찾기
//			//객체지향스러운것 : findMember.getTeam().getName();
//			Member findmember = em.find(Member.class, member.getId());
//			Long findTeamId = findmember.getTeamId();
//			Team findTeam = em.find(Team.class,findTeamId );
			
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
