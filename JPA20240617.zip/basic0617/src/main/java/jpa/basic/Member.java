package jpa.basic;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.*;

@Entity
public class Member {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	
	@Column(name="USER_NAME", nullable = false, 
			columnDefinition = "varchar(100) default 'EMPTY'")
	private String username;
	
//	@Column(name="USER_AGE")
	private Integer age;
	
	//관리자 , 일반
	@Enumerated(EnumType.STRING)
	private RoleType roleType;
	
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date createDate; // 가입날짜
//	
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date lastModifiedDate; //수정날짜
	
	
	private LocalDateTime createDate; // 가입날짜
	
	private LocalDateTime lastModifiedDate; //수정날짜
	
	@Lob
	private String description;
	
	@Transient //mapping하지 않겠다는의미
	private int temp;
	
	public void setRoleType(RoleType roleType) {
		this.roleType = roleType;
	}


	//constrct
	public Member() {}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public LocalDateTime getCreateDate() {
		return createDate;
	}


	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}


	public LocalDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}


	public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getTemp() {
		return temp;
	}


	public void setTemp(int temp) {
		this.temp = temp;
	}


	public RoleType getRoleType() {
		return roleType;
	}

	
	
	
	
	
	
	
	
	
}
