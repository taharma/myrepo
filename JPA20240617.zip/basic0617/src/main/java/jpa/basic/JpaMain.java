package jpa.basic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaMain {
	public static void main(String[] args) {
		// DB연결 성공 , 예외 Exception이 없다면
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_mysql");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		// 트랜젝션 시작
		tx.begin();
		try {
			Member member = new Member();
			member.setUsername("홍길동");
			
			em.persist(member);
			System.out.println(member.getId());
			
			// commit
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		} finally {
			em.close();
		}
		emf.close();// 모두 리소스니까 닫아줘야함
	}
}
